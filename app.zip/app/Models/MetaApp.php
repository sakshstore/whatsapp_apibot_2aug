<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MetaApp extends Model
{
    use HasFactory;
    
    
     
                      
    
    
      protected $fillable = [
       'name','from_phone_number' ,'from_phone_number_id','access_token','status' ,'delete_protected'
    ];




}
