@extends('layouts.app')

@section('template_title')
    {{ __('Update') }} Template
@endsection

@section('content')
    <div class="  container ">
        <div class="">
            <div class="col-md-12">

              {{ __('Update') }} Template 
                        <form method="POST" action="{{ route('templates.update', $template->id) }}"  role="form" enctype="multipart/form-data">
                            {{ method_field('PATCH') }}
                            @csrf

                            @include('template.form')

                        </form>
                     
                </div>
            </div>
        </div>
   
@endsection
