 
        <div class="form-group">
            
            
            
  <input type="text" class="form-control" id="name" name="name" value="" required="">
                   {!! $errors->first('name', '<div class="invalid-feedback">:message</div>') !!}      
                      
                       </div>
    
           
          
          
              <div class="form-group">
            
            
            
  <input type="text" class="form-control" id="message" name="message" value="" required="">
                   {!! $errors->first('message', '<div class="invalid-feedback">:message</div>') !!}      
                      
                       </div>
    
    
     
            
  
  <button type="submit" class="btn btn-primary">{{ __('Submit') }}</button> 