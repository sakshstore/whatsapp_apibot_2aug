@extends('layouts.app')

@section('template_title')
    {{ __('Create') }} Template
@endsection

@section('content')
    <div class="content container  ">
        <div class="row">
            <div class="col-md-12">

          

                
                   {{ __('Create') }} Template 
                  
                        <form method="POST" action="{{ route('templates.store') }}"  role="form" enctype="multipart/form-data">
                            @csrf

                            @include('template.form')

                        </form>
                     
            
            </div>
        </div>
    </div>
@endsection
