<x-mail::message>



{{$message}}

 

Thanks,<br>
{{ config('app.name') }}
</x-mail::message>
